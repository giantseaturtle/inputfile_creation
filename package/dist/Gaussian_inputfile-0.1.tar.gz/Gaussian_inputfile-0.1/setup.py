from setuptools import setup

setup(name='Gaussian_inputfile',
      version='0.1',
      description='Create Gaussian inputfiles',
      packages=['Gaussian_inputfile'],
      author = 'Zhili Wen',
      author_email = 'wenzhili523@gmail.com',
     zip_safe=False)